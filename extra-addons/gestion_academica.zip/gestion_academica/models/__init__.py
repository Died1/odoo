from . import hr_employee
from . import curso
from . import estudiante
from . import materia
from . import paralelo
from . import tutor



