## Module <music_school_institute>

#### 01.04.2024
#### Version 17.0.1.0.0
##### ADD

- Initial Commit for Music School Institute
